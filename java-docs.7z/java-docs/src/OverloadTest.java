
public class OverloadTest {
	public static void main(String[] args) {
		
		OverloadTest s = new OverloadTest();
		//s.m1(10);
		
		AA1 aa1 = new BB1();
		YY y = new YY();
		aa1.m2(y);
		
		XX y1 = new YY();
	//	aa1.m2(y1);
		
		
		//aa1.m3();
	}

	void m1(int i) {
		System.out.println("i");
	}
	void m1(Object ob) {
		System.out.println("ob");
	}
	void m1(Integer integer) {
		System.out.println("integer");
	}
	
	
}

class AA1{
	
	void m1() {
		System.out.println("AA1");
	}
	
	void m2(YY xx) {
		System.out.println("AA1-XX");
	}
	
	void m3() {
		System.out.println("AA1-m3");
	}
}


class BB1 extends AA1{
	
	void m1() {
		System.out.println("BB1");
	}
	
	void m2(YY yy) {
		System.out.println("BB1-YY");
	}
	
	void m3() {
		System.out.println("BB1-m3");
	}
}

class XX{
	
}

class YY extends XX{
	
}
