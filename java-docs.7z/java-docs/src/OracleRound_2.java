import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class OracleRound_2 {
	public static void main(String[] args) {
		int a[] = { -40, -20, 1, 2, 3, 6, 8 };
		continuesSubArray(a);
		int n = a.length;
		int x = 5;
		int l = 0, r = n - 1;
		int m = r;
		int diff = Integer.MAX_VALUE;
		int res_l = 0, res_r = 0;

		while (l < m && r >= 0) {
			// If this pair is closer to x than the previously
			// found closest, then update res_l, res_r and diff
			if (Math.abs(a[l] + a[r] - x) < diff) {
				res_l = l;
				res_r = r;
				diff = Math.abs(a[l] + a[r] - x);
				System.out.println("diff1:" + diff);
			}

			// If sum of this pair is more than x, move to smaller
			// side
			if (a[l] + a[r] > x)
				r--;
			else // move to the greater side
				l++;
		}
		System.out.print("The closest pair is [" + a[res_l] + ", " + a[res_r] + "]");
	}

	static void m1(int a[]) {
		String totals = "";

		for (int i = 0; i < a.length - 2; i++) {
			int count = 0;
			int temp_index = i;
			int original = a.length - 1;
			int current = a.length - 1;
			while (Math.abs(current - original) == 1) {
				current = a[temp_index];
				count += 1;
				if (temp_index < a.length - 1) {
					temp_index += 1;
				}
			}
			totals= totals+":"+count;
		}
		System.out.println(totals);
	}

	static void continuesSubArray(int a[]) {
		// int a[] = { -40, -20, 1,2, 3, 6, 8 };
		int start = 0;
		int end = 0;
		int c = 0;
		Set<Integer> m = new HashSet< Integer>();
		String totals = "";
		boolean a1 = false;
		for (int i = 0; i < a.length - 2; ) {

			while (Math.abs(a[i + 1] - a[i]) == 1) {
				
				m.add(i);
				m.add(i+1);
				a1=true;
				i++;
			} 
			if(a1) {
				i--;
				a1=false;
			}
			i++;
				System.out.println(m);
			
		}

	}
}
