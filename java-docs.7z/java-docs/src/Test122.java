import java.util.*;

public class Test122 {
	public static void main(String[] args) {
		
		List<String > attrList = new ArrayList<String>();
		attrList.add("ddd");
		attrList.add("kkk");
		attrList.add("ddd44");
	    String[] Attrs = attrList.toArray(new String[0]);

	    System.out.println(Attrs);
		

		// String[] Attrs = {"a","b","d"};
		   String[] searchAttributes = new String[Attrs.length + 1];
		    int i;
		    for (i = 0; i < Attrs.length; i++)
		    {
		      searchAttributes[i] = Attrs[i];
		    }
		    searchAttributes[i] = "OBJECT_CLASS_ATTRIBUTE";
		    
		    System.out.println(Arrays.asList(searchAttributes));
		    
		    
			Set s = new HashSet();
			s.add(1);
			s.add(2);
			System.out.println(s);
			
			Set s2 = s;
			
			System.out.println(s);
			Iterator it = s2.iterator();
			while(it.hasNext()) {
				System.out.println(it.next());
			}
			
			System.out.println("===="+s);
			
	}

}
