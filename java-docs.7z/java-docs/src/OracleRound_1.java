import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class OracleRound_1 {
	public static void main(String[] args) {
		
		List<Employee> list = new ArrayList<Employee>();
		
		list.add(new Employee("Anant","tata",1));
		list.add(new Employee("Anand","tata",111));
		list.add(new Employee("Sarvesh","tata",1));
		list.add(new Employee("Ramesh","tata",1));
		list.add(new Employee("Ramesh","Gupta",1));
		list.add(new Employee("Anand","tata",11));
		
		list.stream().forEach(e->System.out.println(e.getFirstName()+":"+e.getLastname()+":"+e.getAge()));
		
		List<Employee> list2 = list.stream().sorted(Comparator.comparing(Employee::getFirstName)
				.thenComparing(Employee::getLastname).thenComparing(Employee::getAge))
				.collect(Collectors.toList());
		
		System.out.println("==========================");
		list2.stream().forEach(e->System.out.println(e.getFirstName()+":"+e.getLastname()+":"+e.getAge()));
	}

}

class Employee{
	
	String firstName;
	String lastname;
	int age;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(String firstName, String lastname, int age) {
		super();
		this.firstName = firstName;
		this.lastname = lastname;
		this.age = age;
	}
	
	
}