package com.java8.stream;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class ExampleConsumerPredicate {
	
	
	Predicate<Student> p1 = (student)->{
		return student.getGradeLevel()>=3;
	};
	
	Predicate<Student> p2 = (student)->student.getGpa()>=3.9;
	BiPredicate<Integer, Double> bip = (gradelevel,gpa)->gradelevel >=3 && gpa>=3.9;
	
	BiConsumer<String, List<String>> b = (name,activities)->System.out.println(name+" "+activities);
	
	Consumer<Student> c1 =(student->{
			if(p1.and(p2).test(student)) {
				b.accept(student.getName(), student.getActivities());
			}
		});
	
	Consumer<Student> c2 =(student->{
		if(bip.test(student.getGradeLevel(),student.getGpa())) {
			b.accept(student.getName(), student.getActivities());
		}
	});
	
	public static void main(String[] args) {
		ExampleConsumerPredicate p = new ExampleConsumerPredicate();
		List<Student> list = StudentDataBase.getAllStudents();
		p.printNameActivities(list);
	}
	
	public void printNameActivities(List<Student> student) {
		student.forEach(c1);
		System.out.println("==============");
		student.forEach(c2);
	}
}
