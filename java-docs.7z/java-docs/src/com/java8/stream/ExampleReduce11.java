package com.java8.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ExampleReduce11 {
	
	static Optional<Student> getHishestGpaUsingMax() {
		return StudentDataBase.getAllStudents()
		.stream()
		.max(Comparator.comparing(Student::getGpa));
	}
	
	static Optional<Student> getHishestGpa() {
		return StudentDataBase.getAllStudents()
		.stream()
		.reduce((s1,s2)->(s1.getGpa()>s2.getGpa())?s1:s2);
	}
	
	
	static int mutliplication(List<Integer> list) {
		Integer hh = list.stream().reduce(2, (a,b)->a*b).intValue();
		return hh;
	}
	
	static Optional<Integer> mutliplicationwithoutIdentity(List<Integer> list) {
		Optional<Integer> hh = list.stream().reduce((a,b)->a*b);
		return hh;
	}
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,3,5,7);
		System.out.println(mutliplication(list));
		
		System.out.println(mutliplicationwithoutIdentity(list).isPresent());
		System.out.println(mutliplicationwithoutIdentity(list).get());
		
		
		List<Integer> list1 = Arrays.asList();
		System.out.println(mutliplicationwithoutIdentity(list1).isPresent());
		if(mutliplicationwithoutIdentity(list1).isPresent()) {
			System.out.println(mutliplicationwithoutIdentity(list1).get());
		}
		
		
		System.out.println(getHishestGpaUsingMax());
		
		System.out.println(getHishestGpa());
		
	}

	
}
