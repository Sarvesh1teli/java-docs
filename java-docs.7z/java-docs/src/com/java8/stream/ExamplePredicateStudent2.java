package com.java8.stream;

import java.util.List;
import java.util.function.Predicate;

public class ExamplePredicateStudent2 {
	
	static Predicate<Student> p1 =(student)->{ return student.getGradeLevel()>=3;};
	static Predicate<Student> p2 =(student)->{ return student.getGpa()>=3.9;};
	
	public static void main(String[] args) {
		filterStudentByGradeLevel();
		System.out.println();
		filterStudentByGPA();
		System.out.println();
		filterStudent();
	}

	static void filterStudentByGradeLevel() {
		List<Student> list = StudentDataBase.getAllStudents();
		list.forEach(student->{
			if(p1.test(student)) {
				System.out.println(student);
			}
		});
	}
	static void filterStudentByGPA() {
		List<Student> list = StudentDataBase.getAllStudents();
		list.forEach(student->{
			if(p2.test(student)) {
				System.out.println(student);
			}
		});
	}
	
	static void filterStudent() {
		List<Student> list = StudentDataBase.getAllStudents();
		list.forEach(student->{
			if(p1.and(p2).test(student)) { //p1.or(p2).test(student) p1.or(p2).negate().test(student)  
				System.out.println(student);
			}else {
				System.out.println();
				System.out.println(student);
			}
		});
	}
}
