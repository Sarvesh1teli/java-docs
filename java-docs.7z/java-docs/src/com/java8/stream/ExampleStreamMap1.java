package com.java8.stream;

import java.util.List;
import java.util.stream.Collectors;

public class ExampleStreamMap1 {
	public static void main(String[] args) {
		System.out.println(nameList());
	}
	
	static List<String> nameList(){
		List<Student> list = StudentDataBase.getAllStudents(); 
		
		List<String> nameList =  list.stream() //stream<student>
		//student as input->student name
		.map(student->student.getName()) //stream<string> Student::getName
		//.map(String::toUpperCase)
		.collect(Collectors.toList());//List<String>
		return nameList;
	}

}
