package com.java8.stream;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ExampleMapIterSortJava8 {
	public static void main(String[] args) {
		Map<Integer,String> map = new HashMap();
		map.put(10, "valu1");
		map.put(30, "valu3");
		map.put(40, "valu4");
		map.put(50, "valu2");
		
		map.entrySet().stream()
		.forEach(e -> System.out.println(e.getKey() + ":" + e.getValue()));
		
		System.out.println("sorted based on key");
		map.entrySet().stream()
		.sorted(Map.Entry.comparingByValue())
		.forEach(e -> System.out.println(e.getKey() + ":" + e.getValue()));
		
		 LinkedHashMap<Integer, String> collect = 
				 map.entrySet().stream()
					.sorted(Map.Entry.comparingByValue())
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue
							,(x,y)->x,LinkedHashMap::new));
		 
		 System.out.println(collect);
		 
	}

}
