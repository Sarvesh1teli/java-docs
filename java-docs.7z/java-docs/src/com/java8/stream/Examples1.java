package com.java8.stream;


import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Examples1 {
	public static void main(String[] args) {
		System.out.println("\n ...................7..............");

		Stream.of("d2", "a2", "b1", "b3", "c")
	    .filter(s -> {
	        System.out.println("filter: " + s);
	        return true;
	    }).forEach(s -> System.out.println("forEach: " + s));
		
		System.out.println("\n ...................6..............");
		IntStream.range(1, 5)
		.mapToObj(m-> "a:" + m)
		.forEach(System.out::println);
		
		System.out.println("\n ...................5..............");
		Stream.of("a1", "a11", "a3")
			  .map(s->s.substring(1))
			  .mapToInt(Integer::parseInt)
			  .max().ifPresent(System.out::println);
		
		
		
		System.out.println("\n ..................4..............");
				Stream.of("Ava", "Aneri", "Alberto")
		 		.sorted().findFirst()
		 		.ifPresent(System.out::println);
		 		
		
		
		System.out.println("\n ...................1..............");
		IntStream ii = IntStream.range(1, 5);
		ii.forEach((n)->System.out.println(n));
		
		System.out.println("\n ..............2....................");
		IntStream.range(1, 10).skip(5).forEach(x->System.out.println(x));
		
		
		System.out.println("\n ...............3.....................");
		int sum = IntStream.range(1, 10).sum();
		System.out.println("sum:"+sum);
		
	}

}
