package com.java8.stream;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


public class ExampleStreamMinByMax20 {
	
	public static void main(String[] args) {
		
		Optional<Student> ll3 = StudentDataBase.getAllStudents()
							.stream()
							.collect(Collectors.minBy(Comparator.comparing(Student::getGpa)));
		
		Optional<Student> ll4 = StudentDataBase.getAllStudents()
				.stream()
				.collect(Collectors.maxBy(Comparator.comparing(Student::getGpa)));
		
	System.out.println("minby-"+ll3.get());
	System.out.println("maxby-"+ll4.get());
		
		List<String> ll = StudentDataBase.getAllStudents()
		.stream()
		.map(s->s.getName())
		.sorted()
		.collect(Collectors.toList());
		
		System.out.println(ll);
		
		
		List<String> ll2 = StudentDataBase.getAllStudents()
				.stream()
				.map(Student::getName)
				.collect(Collectors.toList());
				
				System.out.println(ll2);
	}
	


	
}
