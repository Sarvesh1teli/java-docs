package com.java8.stream;

public class ExamplemapReduce12 {
	public static void main(String[] args) {
		
		System.out.println(nofNoteBooks());
		
		System.out.println(nofNoteBooksUsingSum());
	}

	static int nofNoteBooks() {
		return StudentDataBase.getAllStudents().stream()
						.map(Student::getNoteBooks)
						.reduce(0,(a,b)->a+b);
		
	}
	
	static int nofNoteBooksUsingSum() {
		return StudentDataBase.getAllStudents().stream()
						.map(Student::getNoteBooks)
						.reduce(0,Integer::sum);
		
	}
}
