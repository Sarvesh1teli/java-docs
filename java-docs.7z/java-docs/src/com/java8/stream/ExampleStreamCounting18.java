package com.java8.stream;

import java.util.stream.Collectors;


public class ExampleStreamCounting18 {
	public static void main(String[] args) {
		
		System.out.println(count());

	}
	static Long count() {
		return StudentDataBase.getAllStudents()
		.stream()
		.filter(s->s.getGpa()>3.9)
		.collect(Collectors.counting());
		
	}

	
}
