package com.java8.stream;



public class ExampleFunction2 {
	public static void main(String[] args) {
		String r = performconcat("hello");
		System.out.println(r);
	}
	
	static String performconcat(String str) {
		return ExampleFunction1.addString.apply(str);
	}

}
