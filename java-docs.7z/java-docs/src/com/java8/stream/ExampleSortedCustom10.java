package com.java8.stream;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ExampleSortedCustom10 {
	public static void main(String[] args) {
		System.out.println("Students sorted--");
		sortStudentByname().forEach(System.out::println);
		
		System.out.println("Students sorted- by gps-");
		sortStudentByGpa().forEach(System.out::println);
		
		System.out.println("Students sorted- by Desc--gpa-");
		sortStudentByGpaDesc().forEach(System.out::println);
	}

	static List<Student> sortStudentByname(){
		return StudentDataBase.getAllStudents()
						.stream()
						.sorted(Comparator.comparing(Student::getName))
						.collect(Collectors.toList());
	}
	static List<Student> sortStudentByGpa(){
		return StudentDataBase.getAllStudents()
						.stream()
						.sorted(Comparator.comparing(Student::getGpa))
						.collect(Collectors.toList());
	}
	
	static List<Student> sortStudentByGpaDesc(){
		return StudentDataBase.getAllStudents()
						.stream()
						.sorted(Comparator.comparing(Student::getGpa).reversed())
						.collect(Collectors.toList());
	}
}
