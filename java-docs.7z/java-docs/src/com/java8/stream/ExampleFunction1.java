package com.java8.stream;

import java.util.function.Function;

public class ExampleFunction1 {
	
	static Function<String, String > f = (name)->name.toUpperCase();
	
	static Function<String, String > addString = (name)->name.toUpperCase().concat(" old");
	
	public static void main(String[] args) {
		System.out.println(f.apply("hello world"));
		System.out.println(f.andThen(addString).apply("hello world"));
		System.out.println(f.compose(addString).apply("hello world"));
	}
}
