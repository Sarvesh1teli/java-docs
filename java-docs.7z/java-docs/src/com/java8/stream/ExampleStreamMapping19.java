package com.java8.stream;

import java.util.List;
import java.util.stream.Collectors;


public class ExampleStreamMapping19 {
	
	public static void main(String[] args) {
		List<String> ll = StudentDataBase.getAllStudents()
		.stream()
		.collect(Collectors.mapping(Student::getName ,Collectors.toList()));
		
		System.out.println(ll);
		
		
		List<String> ll2 = StudentDataBase.getAllStudents()
				.stream()
				.map(Student::getName)
				.collect(Collectors.toList());
				
				System.out.println(ll2);
	}
	


	
}
