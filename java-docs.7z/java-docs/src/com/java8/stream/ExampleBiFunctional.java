package com.java8.stream;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Predicate;

public class ExampleBiFunctional {
	static BiFunction<List<Student>, Predicate<Student>, Map<String, Double>> bifun = 
			(studentlist,studpredicate)->{
				Map<String,Double> map = new HashMap();
					
				studentlist.forEach(st->{
					if(studpredicate.test(st)) {
						map.put(st.getName(), st.getGpa());
					}
				});
				
				return map;
			};
		
	public static void main(String[] args) {
		
		List<Student> list = StudentDataBase.getAllStudents();
		Predicate<Student> p = (s->{
			return s.getGradeLevel()>=3.9;
		});
		System.out.println(bifun.apply(list,p));
	}
}
