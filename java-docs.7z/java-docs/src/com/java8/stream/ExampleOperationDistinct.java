package com.java8.stream;

import java.util.List;
import java.util.stream.Collectors;

public class ExampleOperationDistinct {
	public static void main(String[] args) {
		System.out.println(printStudentActvities());
		
		System.out.println(printStudentActvitiesCount());
	}
	static List<String> printStudentActvities(){
		return StudentDataBase.getAllStudents()
						.stream()
						.map(Student::getActivities)//Stream<List<String>
						.flatMap(List::stream)
						.distinct() //Stream<String> ->with distinct  fun performed
						.sorted() //sorted asc
						.collect(Collectors.toList());
	}
	
	static Long printStudentActvitiesCount(){
		return StudentDataBase.getAllStudents()
						.stream()
						.map(Student::getActivities)
						.flatMap(List::stream)
						.distinct()//Stream<String> ->with distinct  fun performed
						
						.count();
	}
}
