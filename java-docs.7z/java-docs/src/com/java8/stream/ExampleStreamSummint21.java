package com.java8.stream;

import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;


public class ExampleStreamSummint21 {
	
	public static void main(String[] args) {
		
		int ll3 = StudentDataBase.getAllStudents()
							.stream()
							.collect(Collectors.summingInt(Student::getNoteBooks));
		
		
	System.out.println("minby-"+ll3);
	
	
	Map<String,List<Student>> vv = StudentDataBase.getAllStudents()
	.stream().collect(Collectors.groupingBy(Student::getGender));
		
	System.out.println(vv);
	
	
	Map<String,List<Student>> vv1 = StudentDataBase.getAllStudents()
			.stream().collect(Collectors.groupingBy(s->s.getGpa()>3.5?"outstanding":"average"));
	
	System.out.println(vv1);
	
	Map<Double,Map<String,List<Student>>> twolevelGrouping = StudentDataBase.getAllStudents()
			.stream().collect(Collectors.groupingBy(Student::getGpa,Collectors.groupingBy(s->s.getGpa()>3.5?"outstanding":"average")));
	
	System.out.println(twolevelGrouping);
	
	
System.out.println("maxby");
	Map<Integer, Optional<Student>> vv4 = StudentDataBase.getAllStudents()
			.stream()
			.collect(Collectors.groupingBy(Student::getGradeLevel,
					Collectors.maxBy(Comparator.comparing(Student::getGpa))));
	
	System.out.println(vv4);
	
	
	Map<Integer, Student> vv5 = StudentDataBase.getAllStudents()
			.stream()
			.collect(Collectors.groupingBy(Student::getGradeLevel,
					Collectors.collectingAndThen(
							Collectors.maxBy(Comparator.comparing(Student::getGpa)),Optional::get)));
	
	System.out.println(vv5);
	
	System.out.println("=========partition==============");
	Predicate<Student> st =s->s.getGpa()>3.5;
	Map<Boolean,List<Student>> part = StudentDataBase.getAllStudents()
	.stream()
	.collect(Collectors.partitioningBy(st));
	
	System.out.println(part);
	
	System.out.println();
		Map<Boolean,Set<Student>> part1 = StudentDataBase.getAllStudents()
				.stream()
				.collect(Collectors.partitioningBy(st,Collectors.toSet()));
				
		System.out.println(part1);
		
	}
	
}
