package com.java8.stream;

public class ExampleAggragtor17 {
	public static void main(String[] args) {
		
	}

}
