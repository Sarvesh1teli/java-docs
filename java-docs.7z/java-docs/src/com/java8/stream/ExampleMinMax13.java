package com.java8.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ExampleMinMax13 {
	public static void main(String[] args) {
		
		List<Integer> list1 = Arrays.asList(5,6,7,8,10);
		
		System.out.println("by reduce ->"+findMaxValue(list1));
		System.out.println("by using max:"+findMaxNum(list1));
		
		List<Integer> list2 = Arrays.asList();
		System.out.println("by reduce ->"+findMaxValue(list2)); // not correct result ,it should return empty
		System.out.println("by reduce  using optional->"+findMaxValuePotinal(list2));
		
		System.out.println("=========================");
		System.out.println(findMinValue(list1));// dont use reduce identity like reduce(0,(a,b)->a>b?a:b);
		System.out.println(findMinValueByUsingMin(list1));
	}
	
	
	static int findMaxValue(List<Integer> list) {
		
		return list.stream().reduce(0,(a,b)->a>b?a:b);
	}
	
	static Optional<Integer> findMaxNum(List<Integer> list) {
		
		return list.stream().max(Comparator.comparing(Integer::intValue));
	}
	
	static Optional<Integer> findMaxValuePotinal(List<Integer> list) {
		
		return list.stream().reduce((a,b)->a>b?a:b);
	}

	
	static Optional<Integer> findMinValue(List<Integer> list) {
		return list.stream().reduce((a,b)->a<b?a:b);
	}
	
	static Optional<Integer> findMinValueByUsingMin(List<Integer> list) {
		return list.stream().min(Comparator.comparing(Integer::intValue));
	}
}
