package com.java8.stream;

import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class ExampleNumericRang16 {
	public static void main(String[] args) {
		IntStream in = IntStream.range(1,50);
		System.out.println("range count:" +in.count());
		
		IntStream inc = IntStream.rangeClosed(1,50);
		System.out.println("inclosed count:" +inc.count());
		
		LongStream ll = LongStream.rangeClosed(1,50);
		
		DoubleStream d = IntStream.range(1,50).asDoubleStream(); // dont have double stream range method
	}

}
