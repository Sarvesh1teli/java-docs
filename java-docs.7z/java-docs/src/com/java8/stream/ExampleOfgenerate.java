package com.java8.stream;

import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class ExampleOfgenerate {
	public static void main(String[] args) {
		
		Stream<String > st = Stream.of("a","v","bb");
		st.forEach(System.out::println);
		
		Stream.iterate(1, x->x*2).limit(10).forEach(System.out::println);
		
		Supplier<Integer> s = new Random()::nextInt;
		Stream.generate(s).limit(10).forEach(System.out::println);
	}

}
