package com.java8.stream;

import java.util.List;
import java.util.function.BiConsumer;

public class ExampleBiConsumer1 {
	
	static BiConsumer<String, List<String>> biconsumer = (name,activities)->{
		System.out.println(name+" "+activities);
	};
	
	public static void nameAndActivity1() {
		List<Student> list = StudentDataBase.getAllStudents();
		list.forEach(student->biconsumer.accept(student.getName(), student.activities));
	}
	
	public static void main(String[] args) {
		
		BiConsumer<String, String > c1 = (a,b)->{
			System.out.println("a->"+a+" b->"+b);
		};
		
		c1.accept("hello", "world");
		
		BiConsumer<Integer, Integer > multiple = (a,b)->{
			System.out.println("a->"+a*b);
		};
		
		BiConsumer<Integer, Integer > divesion = (a,b)->{
			System.out.println("a->"+a/b);
		};
		multiple.andThen(divesion).accept(20,10);
		nameAndActivity1();
	}
	
	

}
