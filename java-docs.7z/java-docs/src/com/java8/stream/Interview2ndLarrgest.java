package com.java8.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Interview2ndLarrgest {
	public static void main(String[] args) {
		
		Function<String,String> abc = Function.identity();

		System.out.println(abc.apply("ABCAAA"));
		
		List<Integer> list = Arrays.asList(1,3,3,5,4);
		
		
		List<Integer> lists = list.stream().sorted(Comparator.comparing(Integer::intValue)
				.reversed()).collect(Collectors.toList());
		
		System.out.println(lists.get(1));
		
		list = Arrays.asList(1,3,3,5,4);
		Integer lists2 = list.stream()
				.sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
				//.collect(Collectors.toList());
		
		System.out.println(lists2);
	}

}
