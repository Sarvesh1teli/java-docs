package com.java8.stream;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;


public class ExampleFunctionStudent1 {
	
	static Function<List<Student>,Map<String, Double> >  studentFun1 = (students->{
		Map<String,Double> map = new HashMap();
		students.forEach(st->{
			if(ExamplePredicateStudent2.p2.test(st)) {
				map.put(st.getName(), st.getGpa());
			}
			
		});
		return map;
	});
	
	public static void main(String[] args) {
		List<Student> list = StudentDataBase.getAllStudents();
		System.out.println(studentFun1.apply(list));
	}

}
