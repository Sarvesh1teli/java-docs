package com.java8.stream;

import java.util.List;
import java.util.stream.Collectors;

public class ExampleStreamFlatMap {
	
	public static void main(String[] args) {
		
		System.out.println("Map-->"+printStudentActvitiesMap());
		System.out.println(printStudentActvities());
	}
	static List<List<String>> printStudentActvitiesMap(){
		return StudentDataBase.getAllStudents()
						.stream()
						.map(Student::getActivities)
						.collect(Collectors.toList());
	}
	
	static List<String> printStudentActvities(){
		return StudentDataBase.getAllStudents()
						.stream()
						.map(Student::getActivities)
						.flatMap(List::stream)
						.collect(Collectors.toList());
	}
}
