package com.java8.stream;

import java.util.Optional;

public class ExampleMatch14 {
	public static void main(String[] args) {
		
		System.out.println(allMatch());
		
		System.out.println(anyMatch());
		System.out.println(noneMatch());
		
		
		System.out.println(findFirst());
		System.out.println(findAny());
	}
	
	static boolean allMatch() {
		return StudentDataBase.getAllStudents()
		.stream().allMatch(s->s.getGpa()>=3.9);
	}
	
	static boolean anyMatch() {
		return StudentDataBase.getAllStudents()
		.stream().anyMatch(s->s.getGpa()>=3.9);
	}
	
	static boolean noneMatch() {
		return StudentDataBase.getAllStudents()
		.stream().noneMatch(s->s.getGpa()>=4.9);
	}

	
	static Optional<Student> findFirst() {
		return StudentDataBase.getAllStudents()
		.stream()
		.filter((s)->s.getGpa()>3.6)
		.findFirst();
	}
	
	static Optional<Student> findAny() {
		return StudentDataBase.getAllStudents()
		.stream()
		.filter((s)->s.getGpa()>3.6)
		.findAny();
	}
}
