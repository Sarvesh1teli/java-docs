package com.java8.stream;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class ExampleSupplier1 {
	
	static Supplier<Student> st = ()->{
		return new Student("Adam",2,3.6,"male", 12,Arrays.asList("swimming", "gymnastics","aerobics"));
	};
	
	static Supplier<List<Student>> st1 = ()->StudentDataBase.getAllStudents();
	public static void main(String[] args) {
		
		System.out.println(st.get());
		System.out.println(st1.get());
	}

}
