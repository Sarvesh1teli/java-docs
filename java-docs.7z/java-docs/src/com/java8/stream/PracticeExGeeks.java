
package com.java8.stream;

import java.util.stream.Stream;

public class PracticeExGeeks {
	public static void main(String[] args) {
		
		Stream<String> stream
        = Stream.of("Geek_First", "Geek_2",
                    "Geek_3", "Geek_4",
                    "Geek_Last");
		
		
		System.out.println(stream.findFirst());
		Stream<Integer> intStream = Stream.of(1, 2, 3, 4, 5, 6, 7);
		//System.out.println(intStream.findFirst());
		System.out.println(intStream.skip(intStream.count()-1).findFirst());
	}

}
