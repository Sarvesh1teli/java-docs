package com.java8.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class ExampleOptimiseRange15 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,3,4,5,6);
		System.out.println(sumValue(list));
		System.out.println(sumValueByIntStream());
		
	}
	static int sumValue(List<Integer> list) {
		
		return list.stream().reduce(0,(x,y)->x+y); // unboxing happening so taking some time
		
	}
	
	static int sumValueByIntStream() {
		return IntStream.rangeClosed(1,6).sum();
	}
}
