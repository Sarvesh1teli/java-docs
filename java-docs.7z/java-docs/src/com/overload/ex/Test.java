package com.overload.ex;

public class Test {
	public static void main(String[] args) {
		
		m1(4);
		System.out.println("-------2----------");
		m2(4);
		
		System.out.println("=============3==========");
		
		 m3(new Object()); // Exact match with object argument. 
	     m3("Deep"); // Exact match with string argument. 
	     m3(10); 
	     m3(10.5f); 
	     m3('a'); 
	     m3(null); 
	     
	     System.out.println("=============4==========");
	     //m4(new Object()); // Exact match not found because The method m1(String) is not applicable with object argument.
	     
	     m4("hello");// Exact match with string argument. 
	     m4(new StringBuffer()); // Exact match with string buffer parameter. 
	    // m4(null);// The method m1(String) is ambiguous for the type
	}

	static void m1(double d) {
		System.out.println("doble d");
	}
	
	static void m1(float d) {
		System.out.println("float d");
	}
	
	
	static void m2(float d) {
		System.out.println("float d");
	}
	
	
	static void m2(Integer d) {
		System.out.println("Integer d");
	}
	
	
	public static void m3(String s) 
	  { 
	     System.out.println("Hello String"); 
	  } 
	public static void m3(Object o) 
	{ 
	   System.out.println("Java Object");  
	 } 
	
	
	public static void m4(String s) 
	  { 
	     System.out.println("Hello String"); 
	  } 
	public static void m4(StringBuffer sf )
	{ 
	   System.out.println("StringBuffer sf");  
	 } 
}
