package com.overload.ex;

public class TestOverride {

	public static void main(String[] args) {

		BB b = new BB();
	}
}

class AA {

	private void m1() {
		System.out.println("private m1");
	}

	protected static void m2() {
		System.out.println("private m1");
	}
	
	
	
	
	
	void exception1(Integer a) {
		System.out.println("private m1");
	}

	void exception2() throws NullPointerException {
		System.out.println("private m1");
	}
	
	
	

}

class BB extends AA {

	void exception1() throws NullPointerException {
		System.out.println("private m1");
	}
	
	void exception2() throws ArithmeticException {
		System.out.println("private m1");
	}
	
	
	
	
	
	
	private void m1() {
		System.out.println("private m1");
	}

	protected static void m2() {
		System.out.println("private m1");
	}
}