package com.overload.ex;

public class Test2 {
	public static void main(String[] args) {
		m1(null);
		Animal m = new Lion();
		m1(m);
		
		
		Animal a = new Animal();
		Lion l = new Lion();
		
		System.out.println("---------1------------");
		a.m2(m);
		a.m2(l);
		System.out.println("-------subclass----------");
		l.m2(l);
		l.m2(a);
		
		System.out.println("----------superclass ref pass------------");
		l.m2(m);
		
		System.out.println("---------superclass ref call-------------");
		Animal m2 = new Lion();
		m2.m2(m);
	}
	
	static void m1(Animal m) {
		System.out.println("Animal--> m");
	}
	
	static void m1(Lion m) {
		System.out.println("Lion--> m");
	}

}

class Animal{
	
	void m2(Animal m) {
		System.out.println("Animal--> m2");
	}
}

class Lion extends Animal{
	void m2(Lion m) {
		System.out.println("Lion--> m2");
	}
}
