package com.implement.queue.usingtwostack;

public class TestCons {
	
	TestCons(){
		System.out.println("no args");
	}
	TestCons(Integer ob){
		System.out.println("OB");
	}
	
	public static void main(String[] args) {
		
		TestCons oo = new TestCons(null);
	}

}

class TESTs{
	
}