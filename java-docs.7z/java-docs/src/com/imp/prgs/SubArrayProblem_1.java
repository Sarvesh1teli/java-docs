package com.imp.prgs;

import java.util.ArrayList;

public class SubArrayProblem_1 {
	public static void main(String[] args) {
		//int input[] = { 135, 101, 170, 125, 79, 159, 163, 65, 106, 146, 82, 28, 162, 92, 196, 143, 28, 37, 192, 5, 103,
		//		154, 93, 183, 22, 117, 119, 96, 48, 127, 172, 139, 70, 113, 68, 100, 36, 95, 104, 12, 123, 134 };
		//int sum = 468;
		int input[]= {10, 9, 8, 7,11, 1, 13};
		int sum = 25;
		findSubArrayApproach_1(input, sum);
		findSubArrayApproach_2(input, input.length, sum);
		
		findSubArrayApproach_3(input, input.length, sum);
	}

	static boolean findSubArrayApproach_1(int input[], int requird) {
		for (int i = 0; i < input.length; i++) {
			int sum = input[i];

			for (int j = i + 1; j < input.length; j++) {
				sum = sum + input[j];
				if (sum == requird) {
					// System.out.println(input[i]+" "+input[i+1]+" "+input[j]);
					System.out.println("Sum found between indexes " + i + " and " + j);
					return true;
				} else if (sum > requird) {
					break;
				}
			}
		}
		return false;
	}

	public static boolean findSubArrayApproach_2(int array[], int n, int required) {
		int sum = array[0];
		int start = 0;
		for (int i = 1; i <= n; i++) {
			while (sum > required && start < i - 1) {
				sum = sum - array[start];
				start++;
			}
			if (sum == required) {
				System.out.println("Sum found between indexes " + start + " and " + (i - 1));
				return true;
			}
			if (i < n) {
				sum = sum + array[i];
				
			}
		}
		return false;
	}

	public static boolean findSubArrayApproach_3(int array[], int n, int required) {
		int sum = array[0];
		int left = 0;
		int rt = 0;
		for (int i = 1; i <= n; i++) {
			
			while (sum > required && left < rt-1 ) {
				sum = sum - array[left];
				left++;
			}
			if (sum == required) {
				System.out.println("Sum found between indexes " + left + " and " + rt);
				return true;
			}
			if (i < n) {
				sum = sum + array[i];
				rt++;
				
			}
		}
		return false;
	}
	
}
