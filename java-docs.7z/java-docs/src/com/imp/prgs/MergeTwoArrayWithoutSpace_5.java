package com.imp.prgs;

import java.util.Arrays;

public class MergeTwoArrayWithoutSpace_5 {
	public static void main(String[] args) {
		int a1[] = {3, 27 ,38, 43};//{ 1, 3, 5, 7 };
		int n = a1.length;
		int a2[] = {9, 10, 82};//{ 0, 2, 6, 8, 9 };
		int m = a2.length;
		mergeTwoArray(a1,a2,n,m);
		int arr1[] = {10};
		int arr2[] = {2,3};
		a1=arr1;
		a2=arr2;
		n = a1.length;
		m = a2.length;
		System.out.println("==================");
		mergeTwoArray(a1,a2,n,m);
		
	}
	static void mergeTwoArray(int a1[],int a2[],int n,int m) {
		System.out.println(Arrays.toString(a1));
		System.out.println(Arrays.toString(a2));
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (a1[i] > a2[j]) {
					int temp = a1[i];
					a1[i] = a2[j];
					a2[j] = temp;
				}
			}
		}
		
		System.out.println(Arrays.toString(a1));
		System.out.println(Arrays.toString(a2));
	}

}
