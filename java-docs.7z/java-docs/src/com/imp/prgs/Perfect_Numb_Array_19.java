package com.imp.prgs;

public class Perfect_Numb_Array_19 {
	static int findElement(int[] arr, int n) {
		int[] leftMax = new int[n];
		leftMax[0] = Integer.MIN_VALUE;

		for (int i = 1; i < n; i++)
			leftMax[i] = Math.max(leftMax[i - 1], arr[i - 1]);

		int rightMin = Integer.MAX_VALUE;

		for (int i = n - 1; i >= 0; i--) {
			System.out.println("leftMax[i]--> "+ leftMax[i]+" arr[i] -->"+arr[i]+" "+ "rightMin-->"+rightMin);
			
			if (leftMax[i] < arr[i] && rightMin > arr[i]) {
				if(i==0) {
					return -1;
				}else {
					return arr[i];
				}
			}
			rightMin = Math.min(rightMin, arr[i]);
		}
		return -1;

	}

	// Driver code
	public static void main(String args[]) {
		int[] arr = { 5, 1, 4, 3, 6, 8, 10, 7, 9 };
		//int[] arr ={4, 2, 5, 7};
		//int[] arr = { 5, 6, 4, 1, 7, 12, 9, 1, 4, 1, 11, 5, 7, 1};
		//int[] arr ={6 ,1 ,10}; 
		int n = arr.length;
		System.out.println("Index of the element is " + findElement(arr, n));
	}
}