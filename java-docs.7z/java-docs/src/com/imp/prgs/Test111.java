package com.imp.prgs;

public class Test111 {
	public static void main(String[] args) {
		
		yy v = new yy();
		Connection con = v.m1();
		System.out.println(con);
		System.out.println(con.getClass().getName() );
		System.out.println(con instanceof Connection);
	}



}
class yy{
	Connection m1(){
		return new privateConnection();
	}
}

interface Connection{
	
	Connection m1();
}

class privateConnection implements Connection{

	@Override
	public Connection m1() {
		System.out.println("hello");
		return null;
	}
	
}