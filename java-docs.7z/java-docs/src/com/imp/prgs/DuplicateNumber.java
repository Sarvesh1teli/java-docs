package com.imp.prgs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DuplicateNumber {
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<Integer>();
		for (int i = 1; i < 30; i++) {
			numbers.add(i);
		}
		// add duplicate number into the list
		numbers.add(22);
		DuplicateNumber dn = new DuplicateNumber();
		System.out.println("Duplicate Number: " + dn.findDuplicateNumber(numbers));
	}

	private int findDuplicateNumber(List<Integer> numbers) {
		int n = numbers.size()-1;
		int total = getSum(numbers);
		int duplicate = total-(n*(n+1)/2);
		return duplicate;
	}

	private int getSum(List<Integer> numbers) {
		//return numbers.stream().reduce(0,(a,b)->a+b);
		return numbers.stream().collect(Collectors.summingInt(Integer::intValue));
	}
}
