package com.imp.prgs;

public class DecToBinCount1s {
	public static void main(String[] args) {
		
		System.out.println(setBitCount(10));
	}

	 static int setBitCount(int num)
	  {
	    int count = 0;
	    while ( num != 0 )
	    {
	      if ( (num & 1) != 0)
	        count++;
	      num >>= 1;
	    }
	    return count;
	  }
}
