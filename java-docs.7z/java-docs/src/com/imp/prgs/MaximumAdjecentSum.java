package com.imp.prgs;

public class MaximumAdjecentSum {
	public static void main(String[] args) {
		 //int arr[] = new int[]{5, 5, 10, 100, 10, 5};
		 //int arr[] = {3, 2, 7, 10};
		// int arr[] = { 12, 9, 7, 33 };
		 int arr[] = {6, 7, 1, 3, 8, 2, 4};
	       System.out.println(FindMaxSum(arr, arr.length));
	}

	private static int FindMaxSum(int[] arr, int length) {
		int include = arr[0];
		int exclude = 0;
		int exclude_new ;
		for(int i=1;i<arr.length;i++) {
			exclude_new = (include>exclude)?include:exclude;
			include = exclude+arr[i];
			exclude = exclude_new;
		}
		return Math.max(exclude, include);
	}

}
