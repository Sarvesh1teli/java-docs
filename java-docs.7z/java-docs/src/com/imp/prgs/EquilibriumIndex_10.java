package com.imp.prgs;

public class EquilibriumIndex_10 {
	public static void main(String[] args) {
		EquilibriumIndex_10 equi = new EquilibriumIndex_10();
		//int arr[] = { 1, 3, 5, 2, -4, 3, 0 };
		// int arr[] = { -7, 1, 5, 2, -4, 3, 0 };
		 //int arr[] = { 0, 1, 3, -2, -1 };
		int arr[] = {1,3,5,2,2};
		int arr_size = arr.length;
		System.out.println("First equilibrium index is " + arr[equi.equilibrium(arr, arr_size)]);
	}

	int equilibrium(int arr[], int n)
    {
		int sum = 0;
		int leftsum = 0;
		for(int i = 0 ;i < n;++i) {
			sum = sum + arr[i];
		}
		
		for(int i = 0 ;i < n;++i) {
			sum = sum - arr[i];
			if(leftsum == sum) {
				return i;
			}
			leftsum = leftsum+arr[i];
		}
		return -1;
    }
}
