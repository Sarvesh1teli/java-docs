package com.thread;

public class SeqThreeThread {
	public static void main(String[] args) {
		
		Object ob = new Object();
		PrintSequenceRunnable p1 = new PrintSequenceRunnable(ob,1);
		PrintSequenceRunnable p2 = new PrintSequenceRunnable(ob,2);

		PrintSequenceRunnable p3 = new PrintSequenceRunnable(ob,0);
		Thread th1 = new Thread(p1,"t1");
		Thread th2 = new Thread(p2,"t2");
		Thread th3 = new Thread(p3,"t3");
		
		th1.start();
		th2.start();
		th3.start();

	}

}

class PrintSequenceRunnable implements Runnable{

    Object lock;
	static int counter = 1;
	int LIMIT= 11;
	int threadNo ;
	
	public PrintSequenceRunnable(Object ob, int threadNo) {
		super();
		lock=ob;
		this.threadNo = threadNo;
	}

	@Override
	public void run() {
		
		while(counter < LIMIT) {
			synchronized (lock) {
				while(counter%3 != threadNo) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread()+" "+counter);
				counter++;
				lock.notifyAll();
			}
			
		}
	}
	
}