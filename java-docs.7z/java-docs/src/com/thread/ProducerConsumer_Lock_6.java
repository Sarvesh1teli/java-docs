package com.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ProducerConsumer_Lock_6 {
	public static void main(String[] args) {
		List<Integer> sharedList = new ArrayList<Integer>();
		Lock lock = new ReentrantLock();
		Condition produceCond = lock.newCondition();
		Condition consumerCond = lock.newCondition();
		ProducerThread p = new ProducerThread(sharedList, lock, produceCond, consumerCond);
		ConsumerThread c = new ConsumerThread(sharedList, lock, produceCond, consumerCond);
		Thread th1 = new Thread(p,"ProducerThread");
		Thread th2 = new Thread(c, "ConsumerThread");
		th2.start();
		th1.start();
	}
}

class ProducerThread implements Runnable{
	List<Integer> sharedList ;
	Lock lock ;
	Condition produceCond ;
	Condition consumerCond ;
	
	public ProducerThread(List<Integer> sharedList, Lock lock, Condition produceCond, Condition consumerCond) {
		super();
		this.sharedList = sharedList;
		this.lock = lock;
		this.produceCond = produceCond;
		this.consumerCond = consumerCond;
	}

	@Override
	public void run() {
		for(int i=1;i<=10;i++) {
			produce(i);
		}
		
	}

	private void produce(int i) {
		
		lock.lock();
		if(sharedList.size() == 2) {
			try {
				System.out.println("producer is waiting.. for consumer has to consume");
				produceCond.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		sharedList.add(i);
		 System.out.println("Produced : " + i);
		consumerCond.signalAll();
		lock.unlock();
		
	}
}

class ConsumerThread implements Runnable{
	List<Integer> sharedList ;
	Lock lock ;
	Condition produceCond ;
	Condition consumerCond ;
	public ConsumerThread(List<Integer> sharedList, Lock lock, Condition produceCond, Condition consumerCond) {
		super();
		this.sharedList = sharedList;
		this.lock = lock;
		this.produceCond = produceCond;
		this.consumerCond = consumerCond;
	}
	
	@Override
	public void run() {
		for(int i=1;i<=10;i++) {
			consume();
		}
		
	}

	private void consume() {
		lock.lock();
		if(sharedList.size() == 0) {
			try {
				System.out.println("consumer is waiting.. for producer has to produce.....");
				consumerCond.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		 System.out.println("CONSUMED: " + sharedList.remove(0));
		produceCond.signalAll();
		lock.unlock();
	}
	
}