package com.thread;

import java.util.concurrent.CountDownLatch;

public class ExCountDownLatch_7 {
	public static void main(String[] args) {
		CountDownLatch c  = new CountDownLatch(3);
		TechLeadCountDown lead1 = new TechLeadCountDown(c);
		TechLeadCountDown lead2 = new TechLeadCountDown(c);
		TechLeadCountDown lead3 = new TechLeadCountDown(c);
		
		Thread th1 = new Thread(lead1,"lead1");
		Thread th2 = new Thread(lead2,"lead2");
		Thread th3 = new Thread(lead3,"lead3");
		th1.start();
		th2.start();
		th3.start();
		
	
		try {
			System.out.println("HR is waiting to distribute the offer");
			c.await();
			System.out.println("Distribute Offer Letter");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

class TechLeadCountDown implements Runnable{

	CountDownLatch c ;
	public TechLeadCountDown(CountDownLatch c) {
		super();
		this.c = c;
	}

	@Override
	public void run() {
		
		try {
			System.out.println(Thread.currentThread().getName()+" : is taking interview");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" : recruted");
		c.countDown();
	}
}