package com.thread;

public class GupShupInterview {
	public static void main(String[] args) {
		
		A a1 = new A();
		A a2 = new A();
		C c = new C(a1);
		B b= new B(a2);
		Thread th1 = new Thread(c,"C");
		Thread th2 = new Thread(b,"B");
		th1.start();
		th2.start();
		
		
		D d1 = new D();
		D d2 = new D();
		E e1 = new E(d1);
		F f1= new F(d2);
		Thread th3 = new Thread(e1,"E");
		Thread th4 = new Thread(f1,"F");
		th3.start();
		th4.start();
	}

}

class C extends Thread {
	
	A a;
	C(A a){
		this.a=a;
	}
	public void run() {
		
		a.m2();
	}
}
class B extends Thread {
	
	A a;
	B(A a){
		this.a=a;
	}
	public void run() {
		
		a.m1();
	}
}

class A{
	
	synchronized void m1() {
		try {
			System.out.println("waiting "+Thread.currentThread().getName());
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("m1");
	}
	
	synchronized void m2() {
		System.out.println("waiting "+Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("m2");
	}
}



class D{
	
	static synchronized void m1() {
		try {
			System.out.println("waiting "+Thread.currentThread().getName());
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("static m1");
	}
	
	static synchronized void m2() {
		System.out.println("waiting "+Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("static m2");
	}
}



class E extends Thread {
	
	D a;
	E(D a){
		this.a=a;
	}
	public void run() {
		
		a.m2();
	}
}
class F extends Thread {
	
	D a;
	F(D a){
		this.a=a;
	}
	public void run() {
		
		a.m1();
	}
}
