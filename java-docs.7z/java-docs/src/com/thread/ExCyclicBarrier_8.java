package com.thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class ExCyclicBarrier_8 {
	public static void main(String[] args) {
		CyclicBarrier c  = new CyclicBarrier(3);
		
		TechLeadCyclicBarrier lead1 = new TechLeadCyclicBarrier(c);
		TechLeadCyclicBarrier lead2 = new TechLeadCyclicBarrier(c);
		TechLeadCyclicBarrier lead3 = new TechLeadCyclicBarrier(c);
		
		Thread th1 = new Thread(lead1,"lead1");
		Thread th2 = new Thread(lead2,"lead2");
		Thread th3 = new Thread(lead3,"lead3");
		th1.start();
		th2.start();
		th3.start();
		
			System.out.println("No work for HR");
		
		
	}
}

class TechLeadCyclicBarrier implements Runnable{

	CyclicBarrier c ;
	public TechLeadCyclicBarrier(CyclicBarrier c) {
		super();
		this.c = c;
	}

	@Override
	public void run() {
		
		try {
			System.out.println(Thread.currentThread().getName() + " recruited developer");
			System.out.println(Thread.currentThread().getName() + " waiting for others to complete....");
			c.await();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("All finished recruiting, " + Thread.currentThread().getName()
			     + " gives offer letter to candidate");
		
	}
}