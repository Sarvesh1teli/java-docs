package com.thread;

import java.util.ArrayList;
import java.util.List;

public class Producer_Consumer_1 {
	public static void main(String[] args) {
		CommonProducerConsumer cpc = new CommonProducerConsumer();
		ConsumerThread_1 c = new ConsumerThread_1(cpc);
		ProdcuerThread p = new ProdcuerThread(cpc);
		
		Thread th1 = new Thread(c);
		Thread th2 = new Thread(p);
		
		th1.start();
		th2.start();
	}

}
class ProdcuerThread implements Runnable{
	CommonProducerConsumer cpc ;
	
	public ProdcuerThread(CommonProducerConsumer cpc) {
		super();
		this.cpc = cpc;
	}

	@Override
	public void run() {
		for(int i =0 ;i<10;i++) {
			cpc.put(i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class ConsumerThread_1 implements Runnable{
	CommonProducerConsumer cpc ;
	
	public ConsumerThread_1(CommonProducerConsumer cpc) {
		super();
		this.cpc = cpc;
	}

	@Override
	public void run() {
		for(int i = 0 ;i<10;i++) {
			cpc.get();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
	}
}

class CommonProducerConsumer{
	
	List<Integer> list = new ArrayList<Integer>();
	int MAX = 3;
	
	synchronized void put(int num) {
		
		if(list.size() == MAX) {
			System.out.println("Size is full + Producer is waiting to produce...");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(Thread.currentThread().getName()+" -"+num);
		list.add(num);
		notifyAll();
	}
	
	synchronized void get() {
		if(list.size() == 0) {
			System.out.println("Size is empty + consumer is waiting to consume...");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(Thread.currentThread().getName()+" -- get--"+list.remove(0));
		notifyAll();
	}
	
	
}