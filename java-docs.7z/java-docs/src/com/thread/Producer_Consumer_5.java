package com.thread;

import java.util.*;

public class Producer_Consumer_5 {
	public static void main(String[] args) {
		
		List<Integer> sharedq = new ArrayList<Integer>();
		Producer p1 = new Producer(sharedq);
		Consumer c1 = new Consumer(sharedq);
		
		Thread th1 = new Thread(p1);
		Thread th2  = new Thread(c1);
		th1.start();
		th2.start();
		
		
	}
}

class Producer implements Runnable{
	List<Integer> sharedq;
	int MAX_SIZE = 3;
	
	
	public Producer(List<Integer> sharedq) {
		super();
		this.sharedq = sharedq;
	}

	@Override
	public void run() {
		for(int i=0;i<5;i++) {;
			produc(i);
		}
	}

	private void produc(int i) {
		synchronized (sharedq) {
			if(sharedq.size() == MAX_SIZE) {
				System.out.println("Waiting to consume data from consumer...");
				try {
					sharedq.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("producing---"+i);
			sharedq.add(i);
			sharedq.notifyAll();
		}
	}
	
}

class Consumer implements Runnable{
	List<Integer> sharedq;
	
	public Consumer(List<Integer> sharedq) {
		super();
		this.sharedq = sharedq;
	}

	@Override
	public void run() {
		for(int i=0;i<5;i++) {;
			consume();
		}
	}

	private void consume() {
		synchronized (sharedq) {
			if(sharedq.size() == 0) {
				System.out.println("Waiting to produce data from producer...");
				try {
					sharedq.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("consumed---"+sharedq.remove(0));
			sharedq.notifyAll();
		}
	}
	
}
