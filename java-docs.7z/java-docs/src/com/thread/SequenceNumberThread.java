package com.thread;

public class SequenceNumberThread {
	public static void main(String[] args) {
		
		for(int i=0;i<10;i++) {
			SeqThread s = new SeqThread(i);
			s.start();
		}
	}

}

class SeqThread extends Thread{
	
	static volatile int counter = 0;
	static int  LIMIT = 20;
	int threadNo ;
	
	SeqThread(int threadNo){
		this.threadNo = threadNo;
	}
	  
	public void run() {
		while(counter<LIMIT) {
			
			while(counter % 10 != threadNo) {
				if(counter == LIMIT) {
					break;
				}
			}
	        System.out.println("Thread "+Thread.currentThread().getName()+ " printed " + counter);
			counter++;

		}
		
	}
}