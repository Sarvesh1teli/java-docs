package com.thread;

import java.util.concurrent.Semaphore;

public class ExSemaphore_9 {
	public static void main(String[] args) {
		Semaphore questionPaperPool = new Semaphore(2);

		TechLead1 techLead1 = new TechLead1(questionPaperPool, "John TL");
		TechLead1 techLead2 = new TechLead1(questionPaperPool, "Doe TL");
		TechLead1 techLead3 = new TechLead1(questionPaperPool, "Mark TL");
		TechLead1 techLead4 = new TechLead1(questionPaperPool, "Albert TL");

		techLead1.start();
		techLead2.start();
		techLead3.start();
		techLead4.start();

		System.out.println("No work for HR manager");
	}

}

class TechLead1 extends Thread {
	Semaphore s;
	String name;

	public TechLead1(Semaphore s, String name) {
		super();
		this.s = s;
		this.name = name;
	}

	public void run() {
		try {

			System.out.println(Thread.currentThread().getName() + " Waiting for test question paper");
			// Acquiring one question paper
			s.acquire();
			System.out.println(Thread.currentThread().getName() + " acquired test paper");
			System.out.println(Thread.currentThread().getName() + " Conducting test");
			Thread.sleep(3000);
			System.out.println(Thread.currentThread().getName() + " Test done giving back the paper");
			// Giving back the acquired question paper
			s.release();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
