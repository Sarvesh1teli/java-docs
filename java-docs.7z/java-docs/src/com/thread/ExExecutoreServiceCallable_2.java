package com.thread;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExExecutoreServiceCallable_2 {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService exe = Executors.newFixedThreadPool(1);
		Future<Integer> f = exe.submit(new SumIntegerCallable(4));
		System.out.println("SumIntegerCallable has returned > "+f.get());
		exe.shutdown();
		
		ExecutorService exe2 = Executors.newFixedThreadPool(1);
		Future<Integer> f1 = exe2.submit(new MyRunnableEx(),1);
		System.out.println("futureInteger.get() > "+f1.get());
		
		Future<?> f2 = exe2.submit(new MyRunnableEx());
		System.out.println("futureInteger.get() > "+f2.get());
		exe2.shutdown();
	}
}

class SumIntegerCallable implements Callable<Integer>{
	Integer n;
	 
    SumIntegerCallable(Integer n) {
           this.n = n;
    }
	@Override
	public Integer call() throws Exception {
		Integer sum = 0;
        for (int i = 0; i <= n; i++) {
               sum += i;
        }
        return sum;
	}
}

class MyRunnableEx implements Runnable {
    @Override
    public void run() {
           System.out.println("----MyRunnable's run()----");
           
    }
}
 
