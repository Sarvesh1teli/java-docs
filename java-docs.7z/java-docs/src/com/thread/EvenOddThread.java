package com.thread;

public class EvenOddThread {
	public static void main(String[] args) {
		
		Comman c = new Comman();
		Odd od = new Odd(c);
		Even even = new Even(c);
		Thread th1 = new Thread(od, "oddThread");
		Thread th2 = new Thread(even, "evenThread");
		th1.start();
		th2.start();
	}

}

class Comman {
	
	boolean flag = false;

	public synchronized void oddDisplay(int i) {
		while (flag == true) {
			try {
				wait(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		flag = true;
		System.out.println(i + " job  started:" + Thread.currentThread().getName());
		notify();
	}

	public synchronized void evenDisplay(int i) {
		if (flag == false) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		flag = false;
		System.out.println(i + " job  started:" + Thread.currentThread().getName());
		notify();
	}
}

class Odd extends Thread {
	Comman comman;

	public Odd(Comman comman) {
		super();
		this.comman = comman;
	}

	public void run() {
		for (int i = 1; i < 11; i++) {
			comman.oddDisplay(i);
			i++;
		}
	}
}

class Even extends Thread {
	Comman comman;

	public Even(Comman comman) {
		super();
		this.comman = comman;
	}

	public void run() {
		for (int i = 2; i < 11; i++) {
			comman.evenDisplay(i);
			i++;
		}
	}
}