package com.thread;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExReentrantLock_4 {
	public static void main(String[] args) {

		Lock lock = new ReentrantLock();
		EmpRunnable c = new EmpRunnable(lock);
		Thread th1 = new Thread(c);
		Thread th2 = new Thread(c);
		th1.start();
		th2.start();
	}
}

class EmpRunnable implements Runnable {
	Lock lock;

	public EmpRunnable(Lock lock) {
		super();
		this.lock = lock;
	}

	@Override
	public void run() {

		System.out.println(Thread.currentThread().getName() + " is Waiting to acquire lock");
		if(lock.tryLock()) {
			System.out.println(Thread.currentThread().getName() + " is acquired lock");
			try {
				System.out.println(Thread.currentThread().getName() + " is sleeping.");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + " has released lock.");
		}else {
			 System.out.println(Thread.currentThread().getName()
                     +" --------------didn't got lock--------------.");
		}
		
		
	}

}