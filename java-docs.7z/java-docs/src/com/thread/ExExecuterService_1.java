package com.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExExecuterService_1 {
	public static void main(String[] args) {
		int numberOftasks = 10;
		int nThreads = 2;
		System.out.println("executor created with 2 threads.");
		ExecutorService execute = Executors.newFixedThreadPool(nThreads);
		for (int i = 0; i < numberOftasks; i++) {
			MyRunnable myRunnable = new MyRunnable(i);
			execute.execute(myRunnable);
		}
		execute.shutdown();
	}
}

class MyRunnable implements Runnable {

	int taskNumber;

	MyRunnable(int taskNumber) {
		this.taskNumber = taskNumber;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " executing task no " + taskNumber);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
