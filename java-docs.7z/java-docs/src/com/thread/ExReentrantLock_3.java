package com.thread;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExReentrantLock_3 {
	public static void main(String[] args) {

		Lock lock = new ReentrantLock();
		CustomerRunnable c = new CustomerRunnable(lock);
		Thread th1 = new Thread(c);
		Thread th2 = new Thread(c);
		th1.start();
		th2.start();
	}
}

class CustomerRunnable implements Runnable {
	Lock lock;

	public CustomerRunnable(Lock lock) {
		super();
		this.lock = lock;
	}

	@Override
	public void run() {

		System.out.println(Thread.currentThread().getName() + " is Waiting to acquire lock");
		lock.lock();
		
		System.out.println(Thread.currentThread().getName() + " is acquired lock");
		try {
			System.out.println(Thread.currentThread().getName() + " is sleeping.");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " has released lock.");
		lock.unlock();
	}

}