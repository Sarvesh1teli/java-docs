package com.thread;
public class DeadLockMain {
 
      public static void main(String[] args){
           
            Object obj1 = new Object();
            Object obj2 = new Object();
           
            MyDeadLock md1 = new MyDeadLock(obj1, obj2);
            MyDeadLock md2 = new MyDeadLock(obj1, obj2);
           
            Thread t1 = new Thread(md1);
            Thread t2 = new Thread(md2);
           
            t1.start();
            t2.start();
      }
}
 
class MyDeadLock implements Runnable{
     
      Object obj1;
      Object obj2;
     
      public MyDeadLock(Object obj1, Object obj2){
            this.obj1 = obj1;
            this.obj2 = obj2;
      }
      public void run(){
            meth1();
            meth2();
      }
     
      public void meth1(){
            //System.out.println("Aquiring Obj-1 in Meth-1"+Thread.currentThread().getName());
            synchronized (obj1) {
                  System.out.println("Aquired Obj-1 in Meth-1 "+Thread.currentThread().getName());
                  try {
                        //System.out.println("Aquiring Obj-2 in Meth-1"+Thread.currentThread().getName());
                        Thread.sleep(2000);
                        synchronized (obj2) {
                              System.out.println("Aquired Obj-2 in Meth-1 "+Thread.currentThread().getName());
                              System.out.println("Method 1"+Thread.currentThread().getName());
                        }
                  } catch (InterruptedException e) {
                        e.printStackTrace();
                  }
            }
      }
     
      public void meth2(){
            //System.out.println("Aquiring Obj-2 in Meth-2"+Thread.currentThread().getName());
            synchronized (obj2) {
                  System.out.println("Aquired Obj-2 in Meth-2 "+Thread.currentThread().getName());
                  try {
                       // System.out.println("Aquiring Obj-1 in Meth-2"+Thread.currentThread().getName());
                        Thread.sleep(2000);
                        synchronized (obj1) {
                              System.out.println("Aquired Obj-1 in Meth-2 "+Thread.currentThread().getName());
                              System.out.println("Method 2"+Thread.currentThread().getName());
                        }
                  } catch (InterruptedException e) {
                        e.printStackTrace();
                  }
            }
      }    
}
 