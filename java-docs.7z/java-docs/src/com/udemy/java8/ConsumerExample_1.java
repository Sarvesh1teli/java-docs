package com.udemy.java8;

import java.util.List;
import java.util.function.Consumer;

public class ConsumerExample_1 {
	
	static Consumer<Student> c1 = (s)->System.out.println(s.getName());
	static Consumer<Student> c2 = (s)->System.out.println(s.getActivities());
	
	public static void main(String[] args) {
		printName();
	}

	private static void printName() {
		
		List<Student> student = StudentDB.getAllStudents();
		
		student.forEach(c1);
	}
	
	

}
