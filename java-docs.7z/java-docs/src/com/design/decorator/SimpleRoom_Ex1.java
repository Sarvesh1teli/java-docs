package com.design.decorator;

public class SimpleRoom_Ex1 implements Room_Ex1 {

	@Override
	public String showRoom() {
		return "Simple Room Constructed";
	}
}
