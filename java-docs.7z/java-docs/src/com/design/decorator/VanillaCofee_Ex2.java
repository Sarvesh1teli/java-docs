package com.design.decorator;

public class VanillaCofee_Ex2 extends CofeeDecorator_Ex2{

	public VanillaCofee_Ex2(Coffee_Ex2 coffe) {
		super(coffe);
	}
	@Override
	 public String flavour() {
	  return super.flavour() +" +Adding Vanilla falvour";
	 }
	  
	 @Override
	 public int getCost() {
	  return super.getCost() + 10;
	 }
}
