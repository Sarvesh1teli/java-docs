package com.design.decorator;

public class DecoratorClient_Ex1 {
	public static void main(String[] args) {
		
		Room_Ex1 room = new CurtainsDecorator_Ex1(new ColorDecorator_Ex1(new SimpleRoom_Ex1()));
		System.out.println(room.showRoom());
	}

}
