package com.design.decorator;

public class DecoratorDesignPattern_Ex2 {

	public static void main(String[] args) {
		
		Coffee_Ex2 cofee = new SimpleCoffee_Ex2();
		System.out.println(cofee.getCost());
		System.out.println(cofee.flavour());
		
		cofee = new VanillaCofee_Ex2(new SimpleCoffee_Ex2());
		System.out.println(cofee.getCost());
		System.out.println(cofee.flavour());
		
		new Strawbery_Ex2(new SimpleCoffee_Ex2());
		System.out.println(cofee.getCost());
		System.out.println(cofee.flavour());
	}
}
