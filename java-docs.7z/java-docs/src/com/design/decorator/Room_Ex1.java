package com.design.decorator;

public interface Room_Ex1 {
	public abstract String showRoom();
}
