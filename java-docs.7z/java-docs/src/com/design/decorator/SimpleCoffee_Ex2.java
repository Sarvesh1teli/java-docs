package com.design.decorator;

public class SimpleCoffee_Ex2 implements Coffee_Ex2{
	@Override
	public int getCost() {
		return 10;
	}
	@Override
	public String flavour() {
		return "Simple coffee";
	}
}
