package com.design.decorator;

public abstract class RoomDecorator_Ex1 implements Room_Ex1 {
	protected Room_Ex1 specialRoom;
	public RoomDecorator_Ex1(Room_Ex1 specialRoom) {
		super();
		this.specialRoom = specialRoom;
	}
	public String showRoom() {
		return specialRoom.showRoom();
	}
}
