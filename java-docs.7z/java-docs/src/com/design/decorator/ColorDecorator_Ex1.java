package com.design.decorator;

public class ColorDecorator_Ex1  extends RoomDecorator_Ex1{
	public ColorDecorator_Ex1(Room_Ex1 specialRoom) {
		super(specialRoom);
	}
	public String showRoom() {
		return specialRoom.showRoom() + addColors();
	}
	private String addColors() {
		return " + Red colors added";
		
	}
}
