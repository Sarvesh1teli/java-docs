package com.design.decorator;

public class Strawbery_Ex2 extends CofeeDecorator_Ex2{

	public Strawbery_Ex2(Coffee_Ex2 coffe) {
		super(coffe);
	}
	@Override
	 public String flavour() {
	  return super.flavour() +" +Adding Strawberry falvour";
	 }
	  
	 @Override
	 public int getCost() {
	  return super.getCost() + 10;
	 }
}
