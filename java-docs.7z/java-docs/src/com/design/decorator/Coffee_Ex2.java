package com.design.decorator;
interface Coffee_Ex2
{
    public int getCost();
    public String flavour();
}