package com.design.decorator;

public abstract class CofeeDecorator_Ex2 implements Coffee_Ex2{

	private Coffee_Ex2 coffe;
	
	
	public CofeeDecorator_Ex2(Coffee_Ex2 coffe) {
		super();
		this.coffe = coffe;
	}

	@Override
	public int getCost() {
		return coffe.getCost();
	}

	@Override
	public String flavour() {
		return coffe.flavour();
	}

}
