package com.design.decorator;

public class CurtainsDecorator_Ex1 extends RoomDecorator_Ex1{
	public CurtainsDecorator_Ex1(Room_Ex1 specialRoom) {
		super(specialRoom);
	}
	public String showRoom() {
		return specialRoom.showRoom() + addCurtains();
	}
	private String addCurtains() {
	    return " + Red Curtains added";
	}
}
