package com.design.factory;

public class Test {

}
