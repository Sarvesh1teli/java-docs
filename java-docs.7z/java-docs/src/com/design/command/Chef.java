package com.design.command;
public class Chef {
	public void cookPasta() {
		System.out.println("Chef is cooking Chicken Alfredo�");
	}

	public void bakeCake() {
		System.out.println("Chef is baking Chocolate Fudge Cake�");
	}
}