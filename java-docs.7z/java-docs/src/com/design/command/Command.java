package com.design.command;
public interface Command {
	public abstract void execute();
}