package com.design.command;

public class CommandClient {
	public static void main(String[] args) {
		
	}
}
