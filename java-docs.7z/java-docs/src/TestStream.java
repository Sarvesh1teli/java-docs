import java.util.Arrays;

public class TestStream {
	public static void main(String[] args) {
		int a[]= {1,2,3,4};
		Arrays.stream(a).filter(n-> n>2).map(i->i*i).forEach(nn->System.out.println(nn));
	}

}
