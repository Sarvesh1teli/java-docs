
public class Oracle_3 {
	public static void main(String[] args) {
		int a[] = { -40, -20, 1, 3, 6, 8 };
		int n = a.length;
		int x = 5;
		int m = 0;
		int y = n-1;
		int diff = Integer.MAX_VALUE;
		int res_l = 0, res_r = 0;
		while(m<n-1 && y>0) {
			
			if(a[m]+a[y]-x < diff) {
				res_l = m;
			}
		}
	}

}
