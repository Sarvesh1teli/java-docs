
public class TestMain {

}


class SessionUtil{
	
	
	static void getConn(String str) {
		
		System.out.println("SessionUtil from str");
	}
}

class AssignmentController{
	
	
	private void getConn() {
		SessionUtil.getConn("Hello");
	}
}