import java.util.ArrayList;
import java.util.List;

public class TestTCS {
	public static void main(String[] args) {
		List<String> s1 = new ArrayList<>();
		s1.add("a");
		s1.add("b");
		s1.add("c");
		
		List<String> s2 = new ArrayList<>();
		s2.add("d");
		s2.add("e");
		s2.add("f");
		
		s2 = s1;
		
		System.out.println(s2);
		System.out.println(s1);
		s1.remove(1);
	
		System.out.println(s2);
		System.out.println(s1);
		
		Integer i = null;
		//int j = i;
	}

}
